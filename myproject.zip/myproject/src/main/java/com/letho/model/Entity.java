package com.letho.model;

public @interface Entity {

}
