package com.letho.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Residence {
    @Id
    private Long id;
    private String name;
    private String roomNumber;
    private boolean isAvailable;

    public Residence() {
        
    }

 
    public Residence(Long id, String name, String roomNumber, boolean isAvailable) {
        this.id = id;
        this.name = name;
        this.roomNumber = roomNumber;
        this.isAvailable = isAvailable;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }
}
