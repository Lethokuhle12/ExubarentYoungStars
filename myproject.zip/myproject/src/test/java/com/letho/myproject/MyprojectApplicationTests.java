package com.letho.myproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes =com.letho.myproject.MyprojectApplication.class)
class MyprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
